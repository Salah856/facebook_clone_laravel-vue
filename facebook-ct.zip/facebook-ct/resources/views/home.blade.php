@extends('layouts.app')

@section('content')
    <App></App>
@endsection
